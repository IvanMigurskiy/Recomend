import re
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import IndexLocator, FixedLocator, MultipleLocator


def parse_log():
    lines = []
    pmf_results = {}
    bpmf_results = {}
    als_results = {}

    with open('log.log') as file:
        lines = [line.rstrip() for line in file]
        for l in lines:
            t = re.findall(r"[-+]?\d*\.\d+|\d+", l)
            t = [int(t[0]), float(t[1]), float(t[2]), int(t[3])]
            if l[0:19] == 'INFO:recommend.pmf:':
                if t[3] in pmf_results:
                    pmf_results[t[3]].append(t)
                else:
                    pmf_results[t[3]] = []
                    pmf_results[t[3]].append(t)
            elif l[0:19] == 'INFO:recommend.bpmf':
                if t[3] in bpmf_results:
                    bpmf_results[t[3]].append(t)
                else:
                    bpmf_results[t[3]] = []
                    bpmf_results[t[3]].append(t)
            elif l[0:19] == 'INFO:recommend.als:':
                if t[3] in als_results:
                    als_results[t[3]].append(t)
                else:
                    als_results[t[3]] = []
                    als_results[t[3]].append(t)



    print(pmf_results)
    print(bpmf_results)
    print(als_results)
    return pmf_results, bpmf_results, als_results
    #return pmf_results[::1], bpmf_results[::1], als_results[::1]

pmf, bpmf, als = parse_log()

pmf_x = []
pmf_y = []
bpmf_x = []
bpmf_y = []
als_x = []
als_y = []


for key, val in pmf.items():
    pmf_x.append(key/100000)
    n = [n[2] for n in val]
    pmf_y.append(min(n))

for key, val in bpmf.items():
    bpmf_x.append(key/100000)
    n = [n[2] for n in val]
    bpmf_y.append(min(n))

for key, val in als.items():
    als_x.append(key/100000)
    n = [n[2] for n in val]
    als_y.append(min(n))

print('\n\n\n')

print(pmf_x, pmf_y)
print('\n\n')
print(bpmf_x, bpmf_y)
print('\n\n')
print(als_x, als_y)


fig = plt.figure(figsize=(7, 4))

ax = fig.add_subplot()
plt.xlabel('Number of samples (/100000)')
plt.ylabel('RMSE')

ax.plot(pmf_x, pmf_y, label='PMF', color='green')


ax.plot(bpmf_x, bpmf_y, label='BPMF', color='red')

ax.plot(als_x, als_y, label='ALS', color='blue')



#ax.yaxis.set_major_locator(FixedLocator([0.75, 0.8, 0.85, 0.9, 0.95, 1.0, 1.05, 1.1, 1.15]))

#ax.xaxis.set_major_locator(MultipleLocator(base=2))

plt.legend(('PMF', 'BPMF', 'ALS'))

plt.show()

